"""
check_email.py
----------------
Check any email text against the trained phishing detection model.

Usage:
  1. Make sure you've already run phishing_detector.py at least once
     (it saves model.joblib, vectorizer.joblib, scaler.joblib).
  2. Run: python check_email.py
  3. Paste or type the email text when prompted, then press Enter.
  4. Type 'quit' to exit.
"""

import os
import joblib
import pandas as pd
from scipy.sparse import hstack, csr_matrix

from phishing_detector import extract_manual_features

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(PROJECT_ROOT, "output")


def load_artifacts():
    try:
        model = joblib.load(os.path.join(OUTPUT_DIR, "model.joblib"))
        vectorizer = joblib.load(os.path.join(OUTPUT_DIR, "vectorizer.joblib"))
        scaler = joblib.load(os.path.join(OUTPUT_DIR, "scaler.joblib"))
    except FileNotFoundError:
        raise SystemExit(
            "Model files not found. Run 'python src/phishing_detector.py' first "
            "to train and save the model."
        )
    return model, vectorizer, scaler


def check_email(text: str, model, vectorizer, scaler):
    series = pd.Series([text])
    tfidf_features = vectorizer.transform(series)
    manual_features = extract_manual_features(series).values
    manual_scaled = scaler.transform(manual_features)
    X = hstack([tfidf_features, csr_matrix(manual_scaled)])

    prediction = model.predict(X)[0]
    proba = model.predict_proba(X)[0]
    confidence = max(proba) * 100
    return prediction, confidence


def main():
    model, vectorizer, scaler = load_artifacts()
    print("Phishing Email Checker — paste an email's text below.")
    print("Type 'quit' to exit.\n")

    while True:
        text = input("Email text: ").strip()
        if text.lower() in {"quit", "exit"}:
            print("Goodbye!")
            break
        if not text:
            continue

        prediction, confidence = check_email(text, model, vectorizer, scaler)
        print(f"\n>>> Prediction: {prediction}  (confidence: {confidence:.1f}%)\n")


if __name__ == "__main__":
    main()
