"""
phishing_detector.py
---------------------
Phishing Email Detection Model (Scikit-learn)

What it does:
  1. Loads a dataset of emails (text, label) from emails_dataset.csv
  2. Extracts features from the text:
       - TF-IDF features from the email text (captures keywords/wording)
       - Hand-crafted features: presence of a URL, number of URLs,
         presence of an IP-based URL, count of urgency/suspicious keywords,
         number of exclamation marks, email length
  3. Trains a classifier (Logistic Regression) to label emails
     as "Phishing" or "Safe"
  4. Prints accuracy and a confusion matrix, plus a text report

Usage:
  python phishing_detector.py

To use your own dataset: replace emails_dataset.csv with a CSV that has
"text" and "label" columns ("Phishing" / "Safe").
"""

import re
import joblib
import numpy as np
import pandas as pd
from scipy.sparse import hstack, csr_matrix

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    ConfusionMatrixDisplay,
)
import matplotlib.pyplot as plt


import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(PROJECT_ROOT, "data", "emails_dataset.csv")
OUTPUT_DIR = os.path.join(PROJECT_ROOT, "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

SUSPICIOUS_KEYWORDS = [
    "urgent", "verify", "suspended", "click here", "act now", "confirm",
    "password", "limited time", "winner", "prize", "free", "immediately",
    "account will be", "security alert", "update your", "login",
]

URL_PATTERN = re.compile(r"https?://[^\s]+")
IP_URL_PATTERN = re.compile(r"https?://\d{1,3}(?:\.\d{1,3}){3}")


# ------------------------------------------------------------------
# 1. Feature engineering helpers
# ------------------------------------------------------------------
def extract_manual_features(texts: pd.Series) -> pd.DataFrame:
    """Hand-crafted features that are known signals of phishing emails."""
    features = pd.DataFrame()

    urls = texts.apply(lambda t: URL_PATTERN.findall(t))
    features["num_urls"] = urls.apply(len)
    features["has_url"] = (features["num_urls"] > 0).astype(int)
    features["has_ip_url"] = texts.apply(lambda t: bool(IP_URL_PATTERN.search(t))).astype(int)

    lowered = texts.str.lower()
    features["keyword_count"] = lowered.apply(
        lambda t: sum(t.count(k) for k in SUSPICIOUS_KEYWORDS)
    )
    features["exclamation_count"] = texts.apply(lambda t: t.count("!"))
    features["text_length"] = texts.apply(len)
    features["capital_ratio"] = texts.apply(
        lambda t: sum(1 for c in t if c.isupper()) / max(len(t), 1)
    )

    return features


# ------------------------------------------------------------------
# 2. Load data
# ------------------------------------------------------------------
def load_data(path: str = DATA_PATH) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.dropna(subset=["text", "label"])
    df["text"] = df["text"].astype(str)
    return df


def main():
    print("Loading dataset...")
    df = load_data()
    print(f"Loaded {len(df)} emails "
          f"({(df['label'] == 'Phishing').sum()} Phishing / "
          f"{(df['label'] == 'Safe').sum()} Safe)")

    X_text = df["text"]
    y = df["label"]

    # ------------------------------------------------------------
    # Train / test split (do this BEFORE fitting vectorizer to avoid leakage)
    # ------------------------------------------------------------
    X_train_text, X_test_text, y_train, y_test = train_test_split(
        X_text, y, test_size=0.2, random_state=42, stratify=y
    )

    # ------------------------------------------------------------
    # 3. TF-IDF features (fit only on training data)
    # ------------------------------------------------------------
    vectorizer = TfidfVectorizer(
        stop_words="english",
        max_features=2000,
        ngram_range=(1, 2),
    )
    X_train_tfidf = vectorizer.fit_transform(X_train_text)
    X_test_tfidf = vectorizer.transform(X_test_text)

    # ------------------------------------------------------------
    # 4. Manual / hand-crafted features
    # ------------------------------------------------------------
    train_manual = extract_manual_features(X_train_text).values
    test_manual = extract_manual_features(X_test_text).values

    # Scale manual features so their larger raw magnitudes (e.g. text_length
    # in the tens/hundreds) don't drown out the 0-1 range TF-IDF features.
    scaler = StandardScaler()
    train_manual_scaled = scaler.fit_transform(train_manual)
    test_manual_scaled = scaler.transform(test_manual)

    # Combine TF-IDF (sparse) + manual features (dense -> sparse)
    X_train = hstack([X_train_tfidf, csr_matrix(train_manual_scaled)])
    X_test = hstack([X_test_tfidf, csr_matrix(test_manual_scaled)])

    # ------------------------------------------------------------
    # 5. Train classifier
    # ------------------------------------------------------------
    print("Training model...")
    model = LogisticRegression(max_iter=1000, class_weight="balanced")
    model.fit(X_train, y_train)

    # ------------------------------------------------------------
    # 6. Evaluate
    # ------------------------------------------------------------
    y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    print(f"\nAccuracy: {acc:.4f} ({acc*100:.2f}%)\n")

    print("Classification Report:")
    print(classification_report(y_test, y_pred))

    cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
    print("Confusion Matrix (rows=actual, cols=predicted):")
    print(pd.DataFrame(cm, index=model.classes_, columns=model.classes_))

    # ------------------------------------------------------------
    # 7. Plot & save confusion matrix
    # ------------------------------------------------------------
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=model.classes_)
    disp.plot(cmap="Blues", values_format="d")
    plt.title(f"Phishing Email Detection - Confusion Matrix\nAccuracy: {acc*100:.2f}%")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "confusion_matrix.png"), dpi=150)
    print(f"\nConfusion matrix image saved to {os.path.join(OUTPUT_DIR, 'confusion_matrix.png')}")

    # ------------------------------------------------------------
    # 8. Try it on a few custom example emails
    # ------------------------------------------------------------
    print("\n--- Testing on new example emails ---")
    examples = [
        "Urgent! Your account has been suspended. Click here to verify: http://192.168.1.5/login",
        "Hi John, attached is the report you asked for. Let me know if you have questions.",
        "Congratulations, you've won a free iPhone! Claim now at http://claim-prize.win/now",
        "Reminder: our weekly sync is moved to 3pm tomorrow.",
    ]
    ex_series = pd.Series(examples)
    ex_tfidf = vectorizer.transform(ex_series)
    ex_manual = extract_manual_features(ex_series).values
    ex_manual_scaled = scaler.transform(ex_manual)
    ex_X = hstack([ex_tfidf, csr_matrix(ex_manual_scaled)])
    ex_pred = model.predict(ex_X)
    ex_proba = model.predict_proba(ex_X)

    for text, pred, proba in zip(examples, ex_pred, ex_proba):
        confidence = max(proba) * 100
        print(f"\n[{pred}] (confidence: {confidence:.1f}%)")
        print(f"  \"{text[:80]}{'...' if len(text) > 80 else ''}\"")

    # ------------------------------------------------------------
    # 9. Save the trained model so check_email.py can reuse it
    # ------------------------------------------------------------
    joblib.dump(model, os.path.join(OUTPUT_DIR, "model.joblib"))
    joblib.dump(vectorizer, os.path.join(OUTPUT_DIR, "vectorizer.joblib"))
    joblib.dump(scaler, os.path.join(OUTPUT_DIR, "scaler.joblib"))
    print(f"\nModel saved in {OUTPUT_DIR}/ (model.joblib, vectorizer.joblib, scaler.joblib).")
    print("You can now run: python src/check_email.py")


if __name__ == "__main__":
    main()
