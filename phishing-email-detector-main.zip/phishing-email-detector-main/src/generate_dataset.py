"""
generate_dataset.py
--------------------
Creates a synthetic dataset of phishing and legitimate emails and saves it
as emails_dataset.csv. Each row has:
    - text  : the email body/subject combined
    - label : "Phishing" or "Safe"

This is a STAND-IN dataset for demo/learning purposes. Replace this with a
real dataset (e.g. from Kaggle "Phishing Email Dataset") for production use
by simply pointing phishing_detector.py at your own CSV with the same
"text","label" columns.
"""

import random
import csv

random.seed(42)

# ---------- Building blocks for PHISHING emails ----------
phishing_subjects = [
    "Urgent: Verify your account now",
    "Your account has been suspended",
    "Action required: Unusual login detected",
    "You have won a $1000 gift card!",
    "Final notice: Payment failed",
    "Security Alert: Confirm your identity",
    "Your password will expire today",
    "Claim your prize before it expires",
    "Immediate action needed: Account locked",
    "Update your billing information now",
]

phishing_bodies = [
    "Dear customer, we noticed suspicious activity on your account. "
    "Click here to verify your identity immediately: http://secure-login-{n}.tk/verify",
    "Your account has been temporarily suspended due to a policy violation. "
    "Restore access now at http://account-verify-{n}.ru/restore or it will be deleted in 24 hours.",
    "Congratulations! You have been selected to receive a free reward. "
    "Claim it now before it expires: http://free-prize-{n}.win/claim",
    "We could not process your last payment. Update your card details urgently "
    "at http://billing-update-{n}.info/pay to avoid service interruption.",
    "Your password expires today. To keep your account active, reset it here: "
    "http://reset-password-{n}.xyz/login immediately.",
    "Unusual sign-in activity was detected from a new device. Confirm this was you "
    "at http://confirm-identity-{n}.top/secure or your account will be locked.",
]

phishing_keywords_extra = [
    "act now", "verify immediately", "limited time", "click below",
    "confirm your identity", "your account will be closed", "urgent action required",
]

# ---------- Building blocks for LEGITIMATE emails ----------
legit_subjects = [
    "Your monthly newsletter",
    "Meeting notes from today",
    "Invoice for your recent purchase",
    "Weekly team update",
    "Your order has shipped",
    "Reminder: Project deadline next week",
    "Welcome to our service",
    "Your subscription receipt",
    "Notes from our call",
    "Schedule for next week",
]

legit_bodies = [
    "Hi team, please find attached the notes from today's meeting. Let me know if I missed anything.",
    "Thank you for your purchase. Your invoice #{n} is attached for your records.",
    "Here is this week's summary of project progress. Overall we are on track to meet the deadline.",
    "Your order #{n} has shipped and should arrive within 3-5 business days.",
    "Just a friendly reminder that the project deadline is next Friday. Let me know if you need support.",
    "Welcome aboard! We're excited to have you. Here is some information to help you get started.",
    "Thanks for subscribing. Your receipt for this billing cycle is attached below.",
    "Following up on our call earlier today, here is a summary of what we discussed.",
    "Attached is the schedule for next week's sessions. Let me know if any times need to change.",
    "Please review the attached document and share your feedback by end of week.",
]


def make_phishing_email(i: int) -> str:
    subject = random.choice(phishing_subjects)
    body = random.choice(phishing_bodies).format(n=random.randint(1000, 9999))
    extra = random.choice(phishing_keywords_extra)
    text = f"{subject}. {body} {extra.capitalize()}."
    # Occasionally a "sneaky" phishing email with fewer red-flag keywords,
    # to avoid the dataset being trivially separable.
    if random.random() < 0.15:
        text = f"{subject}. Please review the attached statement and follow the link if needed."
    return text


def make_legit_email(i: int) -> str:
    subject = random.choice(legit_subjects)
    body = random.choice(legit_bodies).format(n=random.randint(1000, 9999))
    text = f"{subject}. {body}"
    # Occasionally a legit email that mentions a link or urgency-adjacent
    # word, so the model can't rely purely on keyword presence.
    if random.random() < 0.15:
        text += " Please confirm receipt at your earliest convenience: https://company-intranet.com/confirm"
    return text


def build_dataset(n_per_class: int = 250):
    rows = []
    for i in range(n_per_class):
        rows.append((make_phishing_email(i), "Phishing"))
        rows.append((make_legit_email(i), "Safe"))
    random.shuffle(rows)
    return rows


if __name__ == "__main__":
    import os

    rows = build_dataset(n_per_class=250)  # 500 emails total
    out_dir = os.path.join(os.path.dirname(__file__), "..", "data")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "emails_dataset.csv")
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["text", "label"])
        writer.writerows(rows)
    print(f"Generated {len(rows)} emails -> {out_path}")
